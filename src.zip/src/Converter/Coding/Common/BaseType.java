package Converter.Coding.Common;

public enum BaseType {
    INT,FLOAT,STRING,BOOLEAN
}
