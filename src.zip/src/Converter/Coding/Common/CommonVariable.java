package Converter.Coding.Common;

public class CommonVariable {
    /**
     *
     */
    public static final String SENSOR_MAX_BUFFER_SIZE = "SENSOR_MAX_BUFFER_SIZE";

    /**
     *
     */
    public static final String SENSOR_MAX_QUEUE_SIZE = "SENSOR_MAX_QUEUE_SIZE";

    /**
     *
     */
    public static final String CHANNEL_MAX_BUFFER_SIZE = "CHANNEL_MAX_BUFFER_SIZE";

    /**
     *
     */
    public static final String SENSOR_MAX_SENDING_RATE = "SENSOR_MAX_SENDING_RATE";

    /**
     *
     */
    public static final String SENSOR_MIN_SENDING_RATE = "SENSOR_MIN_SENDING_RATE";

    /**
     *
     */
    public static final String SENSOR_MAX_PROCESSING_RATE = "SENSOR_MAX_PROCESSING_RATE";

    /**
     *
     */
    public static final String SENSOR_MIN_PROCESSING_RATE = "SENSOR_MIN_PROCESSING_RATE";

    /**
     *
     */
    public static final String CHANNEL_MAX_SENDING_RATE = "CHANNEL_MAX_SENDING_RATE";

    /**
     *
     */
    public static final String CHANNEL_MIN_SENDING_RATE = "CHANEL_MIN_SENDING_RATE";

    /**
     *
     */
    public static final String NUMBER_OF_PACkAGE = "NUMBER_OF_PACKAGE";

    /**
     *
     */
    public static final String CONGESTION = "CONGESTION";
}
