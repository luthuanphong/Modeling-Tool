package Converter.Coding.Program;

public abstract class BaseProgram {
    public String id;
    public abstract String getCode();
}
