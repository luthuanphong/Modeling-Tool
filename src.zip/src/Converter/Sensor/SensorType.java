package Converter.Sensor;

public enum SensorType {
    SOURCE,SINk,INTERMEDIATE
}
