package Converter;

import Converter.Channel.BaseChannel;
import Converter.Channel.UnicastChannel;
import Converter.Coding.Common.BaseType;
import Converter.Coding.Common.CommonVariable;
import Converter.Coding.Common.Variable;
import Converter.Coding.Program.*;
import Converter.Sensor.BaseSensor;
import Converter.Sensor.SensorFactory;
import Converter.Sensor.SensorType;
import Kwsn.Link;
import Kwsn.Sensor;
import Pnml.Pnml;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.xml.bind.*;

public class UnicastConverter extends Converter {

    private List<Variable> variables;

    private List<String> programs;

    public UnicastConverter (HashMap<String,Object> data) {
        this.setTopologyData(data);
        variables = new ArrayList<>();
        variables.add(new Variable(BaseType.BOOLEAN, CommonVariable.CONGESTION,"false"));
        variables.add(new Variable(BaseType.INT, CommonVariable.SENSOR_MAX_BUFFER_SIZE, getSensorMaxBufferSize(),true));
        variables.add(new Variable(BaseType.INT, CommonVariable.SENSOR_MAX_QUEUE_SIZE, getSensorMaxQueueSize(),true));
        variables.add(new Variable(BaseType.INT, CommonVariable.SENSOR_MAX_PROCESSING_RATE, getSensorMaxProcessingRate(),true));
        variables.add(new Variable(BaseType.INT, CommonVariable.SENSOR_MAX_SENDING_RATE, getSensorMaxSendingRate(),true));
        variables.add(new Variable(BaseType.INT, CommonVariable.CHANNEL_MAX_BUFFER_SIZE, getChannelMaxBufferSize(),true));
        variables.add(new Variable(BaseType.INT, CommonVariable.CHANNEL_MAX_SENDING_RATE, getChannelMaxSendingRate(),true));
        variables.add(new Variable(BaseType.INT, CommonVariable.NUMBER_OF_PACkAGE, getNumberOfPackage()));
        variables.add(new Variable(BaseType.INT, CommonVariable.SENSOR_MIN_SENDING_RATE, getSensorMinSendingRate(),true));
        variables.add(new Variable(BaseType.INT, CommonVariable.SENSOR_MIN_PROCESSING_RATE, getSensorMinProcessingRate(),true));
        variables.add(new Variable(BaseType.INT, CommonVariable.CHANNEL_MIN_SENDING_RATE, getChannelMinSendingRate(),true));

        programs = new ArrayList<>();
        programs.add(MainProgram.getCode());
    }

    @Override
    public void outputPnmlFile(String folderPath) {

        SensorFactory sensorFactory =  new SensorFactory();
        List<Sensor> sensors = getListSensor();
        List<Link> links = getListChannel();
        List<BaseSensor> baseSensors = new ArrayList<>();
        Pnml pnml = new Pnml();

        if( sensors != null ){
            for ( int i = 0 ; i < sensors.size() ; i++) {
                BaseSensor sensor = sensorFactory.getSensor(pnml,sensors.get(i));
                sensor.convertToPnml();
                baseSensors.add(sensor);
                variables.add(sensor.buffer);
                variables.add(sensor.queue);
                if (sensor.Type == SensorType.SOURCE) {

                    BaseProgram genProgram = new GenerateProgram(sensor.Generate.id,sensor);
                    BaseProgram sendProgram = new SensorSendProgram(sensor.Send.id,sensor);
                    programs.add(genProgram.getCode());
                    programs.add(sendProgram.getCode());

                } else if (sensor.Type == SensorType.INTERMEDIATE) {

                    BaseProgram sendProgram = new SensorSendProgram(sensor.Send.id,sensor);
                    programs.add(sendProgram.getCode());

                } else if (sensor.Type == SensorType.SINk) {

                    BaseProgram processProgram = new ProcessProgram(sensor.Process.id,sensor);
                    programs.add(processProgram.getCode());

                }
            }
        }

        if ( links != null ) {
            for ( int i = 0 ; i < links.size() ; i++) {
                BaseChannel channel = new UnicastChannel(links.get(i),pnml,baseSensors);
                channel.ConvertToPnml();
                variables.add(channel.buffer);
                programs.add(channel.getRecvCode());
                programs.add(channel.getSendCode());
            }
        }

        try {
            JAXBContext context = JAXBContext.newInstance(Pnml.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.marshal(pnml,new File(folderPath,"temp.pnml"));
        } catch (JAXBException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void outputProcessFile(String folderPath) {

        try {
            FileWriter writer = new FileWriter(new File( folderPath,"temp.txt"));
            for (Variable v : variables) {
                writer.write(v.toString());
                writer.write(System.lineSeparator());
            }
            for (String s : programs) {
                writer.write(s);
                writer.write(System.lineSeparator());
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void outputMinimizeProcessFile(String folderPath) {
        try {
            FileWriter writer = new FileWriter(new File(folderPath,"temp_minimize.txt"));
            for (Variable v : variables) {
                writer.write(v.toMinimizeString());
                writer.write(System.lineSeparator());
            }
            for (String s : programs) {
                writer.write(s);
                writer.write(System.lineSeparator());
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
