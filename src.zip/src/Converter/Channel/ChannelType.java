package Converter.Channel;

public enum ChannelType {
    UNICAST,BROADCAST
}
