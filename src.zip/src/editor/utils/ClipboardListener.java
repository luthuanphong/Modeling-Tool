package editor.utils;

public interface ClipboardListener {
	public void clipboardChanged();
}
