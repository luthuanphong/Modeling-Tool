package editor.utils;

public interface BackgroundCallBack {
	void TransferSignal(String value);
	void UpdateProgressStatus();
	void UpdateButton();
}
