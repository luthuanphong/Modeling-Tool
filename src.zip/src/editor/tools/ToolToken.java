package editor.tools;

public class ToolToken implements Tool {

}
