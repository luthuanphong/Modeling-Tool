package editor.canvas;

public class SensorType {
	
	public static final String SOURCE = "Source";
	
	public static final String SINK = "Sink";
	
	public static final String INTERMEDIATE = "Intermediate";
	
}
