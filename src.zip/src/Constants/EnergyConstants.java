package Constants;

public class EnergyConstants {
    public static final String PROCESSING_MESSAGE_ENERGY_CONSUMPTION_KEY = "1";
    public static final String SENDING_MESSAGE_ENERGY_COMSUMPTION_KEY = "2";
    public static final String RECEIVE_MESSAGE_ENERGY_COMSUMPTION_KEY = "3";
}
