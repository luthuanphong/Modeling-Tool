package Petrinet;

public enum Direction {
	PLACE_TO_TRANSITION,
	TRANSITION_TO_PLACE
}
