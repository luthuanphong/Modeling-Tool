cd ../bin
java -cp ../antlr-4.5.3-complete.jar:../bin/ptnet/parser:../bin:../bin/ast/struct ast.test.Test
