javac -d ../bin -cp ../antlr-4.5.3-complete.jar:../bin/ptnet/parser:../bin:../bin/ast/struct ../ptnet/*.java ../error/*.java ../struct/*.java ../gen/*.java ../test/*.java
