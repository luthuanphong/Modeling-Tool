cd ../grammar
java -jar ../antlr-4.5.3-complete.jar -o ../ptnet -no-listener -visitor PTNET.g4
cd ../script

